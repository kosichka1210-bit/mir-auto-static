(() => {
  const menus = Array.from(document.querySelectorAll('.mobile-menu'));
  if (!menus.length) return;

  const syncPageState = () => {
    const hasOpenMenu = menus.some((menu) => menu.open);
    document.body.classList.toggle('mobile-menu-open', hasOpenMenu);
  };

  const closeMenu = (menu) => {
    menu.open = false;
    const trigger = menu.querySelector('summary');
    if (trigger) {
      trigger.setAttribute('aria-expanded', 'false');
      trigger.setAttribute('aria-label', 'Открыть меню');
    }
    syncPageState();
  };

  menus.forEach((menu) => {
    const trigger = menu.querySelector('summary');
    if (trigger) trigger.setAttribute('aria-expanded', 'false');

    menu.addEventListener('toggle', () => {
      if (menu.open) {
        menus.forEach((otherMenu) => {
          if (otherMenu !== menu) closeMenu(otherMenu);
        });
      }

      if (trigger) {
        trigger.setAttribute('aria-expanded', String(menu.open));
        trigger.setAttribute('aria-label', menu.open ? 'Закрыть меню' : 'Открыть меню');
      }
      syncPageState();
    });

    menu.querySelectorAll('nav a').forEach((link) => {
      link.addEventListener('click', () => closeMenu(menu));
    });
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') menus.forEach(closeMenu);
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 960) menus.forEach(closeMenu);
  });
})();
