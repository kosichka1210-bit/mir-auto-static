(function () {
  const form = document.querySelector('.request-form');
  if (!form) return;

  const endpoint = form.dataset.endpoint || 'https://bot.mir-auto-china.ru/api/contact.php';
  const button = form.querySelector('button');
  if (!button) return;
  button.type = 'submit';
  ['name', 'contact', 'model', 'budget'].forEach((name) => {
    const input = form.querySelector(`[name="${name}"]`);
    if (input) input.required = true;
  });

  let status = form.querySelector('.form-status');
  if (!status) {
    status = document.createElement('small');
    status.className = 'form-status';
    status.hidden = true;
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
    form.append(status);
  }

  let honeypot = form.querySelector('[name="website"]');
  if (!honeypot) {
    honeypot = document.createElement('input');
    honeypot.name = 'website';
    honeypot.tabIndex = -1;
    honeypot.autocomplete = 'off';
    honeypot.setAttribute('aria-hidden', 'true');
    honeypot.style.cssText = 'position:absolute;left:-10000px;width:1px;height:1px;opacity:0';
    form.append(honeypot);
  }

  let lastSubmitAt = 0;
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (Date.now() - lastSubmitAt < 4000) return;
    const data = Object.fromEntries(new FormData(form).entries());
    lastSubmitAt = Date.now();
    button.disabled = true;
    status.hidden = false;
    status.textContent = 'Отправляем заявку…';
    status.dataset.state = 'pending';
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || !result || result.ok !== true) throw new Error('delivery_failed');
      form.reset();
      status.textContent = 'Заявка отправлена. Представитель свяжется с вами в ближайшее время.';
      status.dataset.state = 'success';
    } catch (error) {
      status.textContent = 'Не удалось отправить заявку. Позвоните представителю или попробуйте ещё раз.';
      status.dataset.state = 'error';
    } finally {
      button.disabled = false;
      honeypot.value = '';
    }
  });
})();
