(() => {
  'use strict';

  const API = 'https://bot.mir-auto-china.ru/api/cars.php';
  const rootPrefix = location.pathname.includes('/avtomobili/') ? '../' : '';
  const grid = document.querySelector('.catalog-grid') || document.querySelector('#cars .car-grid');

  if (!grid) return;

  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#039;');

  const text = (value) => escapeHtml(value).trim();
  const number = (value) => new Intl.NumberFormat('ru-RU').format(Number(value));

  const makeCard = (car) => {
    const image = Array.isArray(car.images) ? car.images[0] : '';
    if (!image) return '';

    const title = [car.brand, car.model].filter(Boolean).join(' ');
    if (!title) return '';

    const detailsUrl = `${rootPrefix}avtomobili/avtomobil/?slug=${encodeURIComponent(car.slug)}`;
    const facts = [
      car.year,
      car.mileage_km ? `${number(car.mileage_km)} км` : ''
    ].filter(Boolean);
    const status = car.status ? text(car.status) : 'В наличии';
    const price = car.price_rub ? `${number(car.price_rub)} ₽` : 'Цена по запросу';
    const location = car.price_location ? ` · ${text(car.price_location)}` : '';
    const contact = `${rootPrefix}#form`;

    return `<article class="car-card live-car-card">
      <a class="car-image car-photo" href="${detailsUrl}" aria-label="Подробнее о ${text(title)}"><img src="${escapeHtml(image)}" alt="${text(title)}" loading="lazy"></a>
      <div class="car-card-body">
        <p class="car-status">${status}</p>
        <h3>${text(title)}</h3>
        ${facts.length ? `<p class="car-specs">${facts.map(text).join(' · ')}</p>` : ''}
        <p class="car-price">${price}<small>${location}</small></p>
        <div class="catalog-card-actions"><a class="arrow-link" href="${detailsUrl}">Подробнее <b>↗</b></a><a class="catalog-discuss" href="${contact}">Обсудить</a></div>
      </div>
    </article>`;
  };

  fetch(API, { headers: { Accept: 'application/json' } })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('catalog unavailable')))
    .then((payload) => {
      if (!payload || !Array.isArray(payload.cars)) return;
      const limit = grid.classList.contains('catalog-grid') ? 60 : 6;
      const staticSlugs = new Set((window.MIR_AUTO_CARS || []).map((car) => car.slug));
      const cards = payload.cars.filter((car) => !staticSlugs.has(car.slug)).slice(0, limit).map(makeCard).filter(Boolean).join('');
      if (cards) grid.insertAdjacentHTML('afterbegin', cards);
    })
    .catch(() => { /* Static catalogue remains available if the live feed is unavailable. */ });
})();
