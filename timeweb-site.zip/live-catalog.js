(() => {
  'use strict';

  const API = 'https://mir-auto-china.ru/api/cars.php';
  const API_ORIGIN = new URL(API).origin;
  const siteRoot = new URL(location.pathname.includes('/mir-auto-static/') ? '/mir-auto-static/' : '/', location.origin);
  const grid = document.querySelector('.catalog-grid') || document.querySelector('#cars .car-grid');

  if (!grid) return;

  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#039;');

  const text = (value) => escapeHtml(value).trim();
  const number = (value) => {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? new Intl.NumberFormat('ru-RU').format(numeric) : '';
  };
  const imageUrl = (value) => {
    const source = String(value || '').trim();
    if (!source) return '';
    try {
      return new URL(source, `${API_ORIGIN}/`).href;
    } catch (_) {
      return '';
    }
  };
  const markBrokenImage = (image) => {
    const frame = image.closest('.car-photo');
    if (!frame) return;
    image.hidden = true;
    frame.classList.add('is-missing');
  };
  grid.addEventListener('error', (event) => {
    if (event.target instanceof HTMLImageElement) markBrokenImage(event.target);
  }, true);

  const makeCard = (car) => {
    const image = imageUrl(Array.isArray(car.images) ? car.images[0] : '');

    const title = String(car.title || [car.brand, car.model].filter(Boolean).join(' ')).trim();
    if (!title) return '';

    const detailsUrl = new URL(`avtomobili/avtomobil/?slug=${encodeURIComponent(car.slug)}`, siteRoot).href;
    const facts = [
      car.year,
      car.mileage_km ? `${number(car.mileage_km)} км` : '',
      [car.engine, car.power].filter(Boolean).join(' · '),
      car.transmission
    ].filter(Boolean);
    const status = car.status ? text(car.status) : 'В наличии';
    const price = car.price_rub ? `${number(car.price_rub)} ₽` : 'Цена по запросу';
    const contact = new URL('#form', siteRoot).href;
    const photo = image
      ? `<img src="${escapeHtml(image)}" alt="${text(title)} из Китая — MIR AUTO" loading="lazy">`
      : '<span class="car-photo-placeholder" aria-hidden="true">Фото скоро</span>';

    return `<article class="car-card live-car-card">
      <a class="car-photo${image ? '' : ' is-missing'}" href="${detailsUrl}" aria-label="Подробнее о ${text(title)}">${photo}</a>
      <div class="car-copy">
        <div class="car-top"><p class="status">${status}</p><p class="price">${price}</p></div>
        <h3>${text(title)}</h3>
        ${facts.length ? `<p class="car-specs">${facts.slice(0, 3).map(text).join(' · ')}</p>` : ''}
        <div class="catalog-card-actions"><a class="arrow-link" href="${detailsUrl}">Подробнее <b>↗</b></a><a class="catalog-discuss" href="${contact}">Обсудить</a></div>
      </div>
    </article>`;
  };

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 6000);

  fetch(API, { headers: { Accept: 'application/json' }, signal: controller.signal })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('catalog unavailable')))
    .then((payload) => {
      if (!payload || !Array.isArray(payload.cars)) return;
      const limit = grid.classList.contains('catalog-grid') ? 60 : 6;
      const staticSlugs = new Set((window.MIR_AUTO_CARS || []).map((car) => car.slug));
      const cards = payload.cars.filter((car) => !staticSlugs.has(car.slug)).slice(0, limit).map(makeCard).filter(Boolean).join('');
      if (cards) {
        grid.insertAdjacentHTML('afterbegin', cards);
        grid.querySelectorAll('.live-car-card .car-photo img').forEach((image) => {
          if (image.complete && !image.naturalWidth) markBrokenImage(image);
        });
      }
    })
    .catch(() => { /* Static catalogue remains available if the live feed is unavailable. */ })
    .finally(() => window.clearTimeout(timeout));
})();
