(() => {
  'use strict';

  // Статический каталог уже построен из data/cars.js. Живой API здесь не
  // добавляем повторно, чтобы карточки не дублировались.
  if (Array.isArray(window.MIR_AUTO_CARS)) return;

  const API = 'https://bot.mir-auto-china.ru/api/cars.php';
  const rootPrefix = location.pathname.includes('/avtomobili/') ? '../' : '';
  const grid = document.querySelector('.catalog-grid') || document.querySelector('#cars .car-grid');

  if (!grid) return;

  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#039;');

  const text = (value) => escapeHtml(value).trim();
  const number = (value) => new Intl.NumberFormat('ru-RU').format(Number(value));

  const makeCard = (car) => {
    const image = Array.isArray(car.images) ? car.images[0] : '';
    if (!image) return '';

    const title = [car.brand, car.model].filter(Boolean).join(' ');
    if (!title) return '';

    const facts = [
      car.year,
      car.mileage ? `${number(car.mileage)} км` : ''
    ].filter(Boolean);
    const status = car.status ? text(car.status) : 'В наличии';
    const price = car.price_rub ? `${number(car.price_rub)} ₽` : 'Цена по запросу';
    const location = car.price_location ? ` · ${text(car.price_location)}` : '';
    const contact = `${rootPrefix}#form`;

    return `<article class="car-card live-car-card">
      <a class="car-image" href="${contact}" aria-label="Уточнить ${text(title)}"><img src="${escapeHtml(image)}" alt="${text(title)}" loading="lazy"></a>
      <div class="car-card-body">
        <p class="car-status">${status}</p>
        <h3>${text(title)}</h3>
        ${facts.length ? `<p class="car-specs">${facts.map(text).join(' · ')}</p>` : ''}
        <p class="car-price">${price}<small>${location}</small></p>
        <a class="arrow-link" href="${contact}">Уточнить автомобиль <b>↗</b></a>
      </div>
    </article>`;
  };

  fetch(API, { headers: { Accept: 'application/json' } })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('catalog unavailable')))
    .then((payload) => {
      if (!payload || !Array.isArray(payload.cars)) return;
      const limit = grid.classList.contains('catalog-grid') ? 60 : 6;
      const cards = payload.cars.slice(0, limit).map(makeCard).filter(Boolean).join('');
      if (cards) grid.insertAdjacentHTML('afterbegin', cards);
    })
    .catch(() => { /* Static catalogue remains available if the live feed is unavailable. */ });
})();
