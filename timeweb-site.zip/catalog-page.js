(() => {
  'use strict';
  const grid = document.querySelector('.catalog-grid');
  if (!grid || !Array.isArray(window.MIR_AUTO_CARS)) return;
  const esc = (value) => String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  grid.innerHTML = window.MIR_AUTO_CARS.map((car) => {
    const image = car.images && car.images[0]; if (!image) return '';
    const facts = [car.year, car.mileage, [car.engine, car.power].filter(Boolean).join(' · '), car.transmission].filter(Boolean).slice(0, 3);
    return `<article class="car-card"><a class="car-photo" href="${esc(car.slug)}/"><img src="${esc(image)}" alt="${esc(car.title)} из Китая — MIR AUTO" loading="lazy"></a><div class="car-copy"><div class="car-top"><p class="status">${esc(car.status || 'В наличии')}</p>${car.price ? `<p class="price">${esc(car.price)}</p>` : ''}</div><h2>${esc(car.title)}</h2>${facts.length ? `<p class="car-specs">${facts.map(esc).join(' · ')}</p>` : ''}<div class="catalog-card-actions"><a class="arrow-link" href="${esc(car.slug)}/">Подробнее <b>↗</b></a><a class="catalog-discuss" href="../#form">Обсудить</a></div></div></article>`;
  }).join('');
})();
