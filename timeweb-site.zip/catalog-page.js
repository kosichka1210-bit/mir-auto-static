(() => {
  'use strict';
  const grid = document.querySelector('.catalog-grid');
  if (!grid || !Array.isArray(window.MIR_AUTO_CARS)) return;
  const esc = (value) => String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  const siteRoot = new URL(location.pathname.includes('/mir-auto-static/') ? '/mir-auto-static/' : '/', location.origin);
  const assetUrl = (value) => {
    const source = String(value || '').trim();
    if (!source) return '';
    try {
      if (/^https?:\/\//i.test(source)) return new URL(source).href;
      return new URL(source.replace(/^(\.\.\/)+/, ''), siteRoot).href;
    } catch (_) {
      return '';
    }
  };
  const markBrokenImage = (image) => {
    const frame = image.closest('.car-photo');
    if (!frame) return;
    image.hidden = true;
    frame.classList.add('is-missing');
  };
  grid.addEventListener('error', (event) => {
    if (event.target instanceof HTMLImageElement) markBrokenImage(event.target);
  }, true);
  grid.innerHTML = window.MIR_AUTO_CARS.map((car) => {
    const image = assetUrl(car.images && car.images[0]);
    const facts = [car.year, car.mileage, [car.engine, car.power].filter(Boolean).join(' · '), car.transmission].filter(Boolean).slice(0, 3);
    const photo = image
      ? `<img src="${esc(image)}" alt="${esc(car.title)} из Китая — MIR AUTO" loading="lazy">`
      : '<span class="car-photo-placeholder" aria-hidden="true">Фото скоро</span>';
    return `<article class="car-card"><a class="car-photo${image ? '' : ' is-missing'}" href="${esc(car.slug)}/" aria-label="Подробнее о ${esc(car.title)}">${photo}</a><div class="car-copy"><div class="car-top"><p class="status">${esc(car.status || 'В наличии')}</p>${car.price ? `<p class="price">${esc(car.price)}</p>` : ''}</div><h2>${esc(car.title)}</h2>${facts.length ? `<p class="car-specs">${facts.map(esc).join(' · ')}</p>` : ''}<div class="catalog-card-actions"><a class="arrow-link" href="${esc(car.slug)}/">Подробнее <b>↗</b></a><a class="catalog-discuss" href="../#form">Обсудить</a></div></div></article>`;
  }).join('');
  grid.querySelectorAll('.car-photo img').forEach((image) => {
    if (image.complete && !image.naturalWidth) markBrokenImage(image);
  });
})();
