(() => {
  'use strict';
  const main = document.querySelector('[data-car]');
  if (!main || !Array.isArray(window.MIR_AUTO_CARS)) return;
  const car = window.MIR_AUTO_CARS.find((item) => item.slug === main.dataset.car);
  if (!car) return;
  const escapeHtml = (value) => String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  const siteRoot = new URL(location.pathname.includes('/mir-auto-static/') ? '/mir-auto-static/' : '/', location.origin);
  const assetUrl = (value) => {
    const source = String(value || '').trim();
    if (!source) return '';
    try {
      if (/^https?:\/\//i.test(source)) return new URL(source).href;
      return new URL(source.replace(/^(\.\.\/)+/, ''), siteRoot).href;
    } catch (_) {
      return '';
    }
  };
  const imageList = car.images.map(assetUrl).filter(Boolean);
  const specs = [
    ['Год', car.year], ['Пробег', car.mileage],
    ['Двигатель', [car.engine, car.power].filter(Boolean).join(' · ')],
    ['Привод', car.drive], ['Коробка передач', car.transmission], ['Комплектация', car.equipment]
  ].filter(([, value]) => value);
  const gallery = imageList.length ? `
    <section class="vehicle-gallery" aria-label="Фотографии ${escapeHtml(car.title)}">
      <div class="vehicle-gallery-stage">
        <img class="vehicle-gallery-main" src="${escapeHtml(imageList[0])}" alt="${escapeHtml(car.title)} из Китая — MIR AUTO">
        ${imageList.length > 1 ? '<button class="gallery-arrow gallery-prev" type="button" aria-label="Предыдущее фото">←</button><button class="gallery-arrow gallery-next" type="button" aria-label="Следующее фото">→</button>' : ''}
      </div>
      ${imageList.length > 1 ? `<div class="gallery-thumbs" role="tablist">${imageList.map((image, index) => `<button class="gallery-thumb${index === 0 ? ' is-active' : ''}" type="button" data-index="${index}" aria-label="Открыть фото ${index + 1}"><img src="${escapeHtml(image)}" alt="${escapeHtml(car.title)} — фото ${index + 1}"></button>`).join('')}</div>` : ''}
    </section>` : '<section class="vehicle-gallery"><div class="vehicle-gallery-stage is-missing"><span>Фото скоро</span></div></section>';
  const contactUrl = new URL('#form', siteRoot).href;
  main.querySelector('.vehicle-grid').innerHTML = `${gallery}<section class="vehicle-details"><p class="status">${escapeHtml(car.status || 'В наличии')}</p><h1>${escapeHtml(car.title)}</h1>${car.price ? `<p class="vehicle-price">${escapeHtml(car.price)}</p>` : ''}${car.priceNote ? `<p class="vehicle-note">${escapeHtml(car.priceNote)}</p>` : ''}${specs.length ? `<dl class="spec-list">${specs.map(([label, value]) => `<div><dt>${label}</dt><dd>${escapeHtml(value)}</dd></div>`).join('')}</dl>` : ''}${car.description ? `<p class="vehicle-text">${escapeHtml(car.description)}</p>` : ''}<div class="vehicle-actions"><a class="button" href="${contactUrl}">Обсудить автомобиль</a><a class="button button-outline" href="https://t.me/mirautochina125" target="_blank" rel="noopener">Написать в Telegram</a></div></section>`;
  const galleryRoot = main.querySelector('.vehicle-gallery');
  if (!galleryRoot || imageList.length < 2) return;
  let current = 0;
  const mainImage = galleryRoot.querySelector('.vehicle-gallery-main');
  const thumbs = [...galleryRoot.querySelectorAll('.gallery-thumb')];
  mainImage.addEventListener('error', () => {
    mainImage.hidden = true;
    galleryRoot.querySelector('.vehicle-gallery-stage').classList.add('is-missing');
  });
  const show = (index) => { current = (index + imageList.length) % imageList.length; mainImage.src = imageList[current]; mainImage.alt = `${car.title} из Китая — фото ${current + 1} — MIR AUTO`; thumbs.forEach((thumb, i) => thumb.classList.toggle('is-active', i === current)); };
  galleryRoot.querySelector('.gallery-prev').addEventListener('click', () => show(current - 1));
  galleryRoot.querySelector('.gallery-next').addEventListener('click', () => show(current + 1));
  thumbs.forEach((thumb) => thumb.addEventListener('click', () => show(Number(thumb.dataset.index))));
  let startX = 0;
  mainImage.addEventListener('touchstart', (event) => { startX = event.changedTouches[0].screenX; }, { passive:true });
  mainImage.addEventListener('touchend', (event) => { const delta = event.changedTouches[0].screenX - startX; if (Math.abs(delta) > 40) show(current + (delta < 0 ? 1 : -1)); }, { passive:true });
})();
