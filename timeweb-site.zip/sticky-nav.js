(() => {
  const header = document.querySelector('.site-header');
  const hero = document.querySelector('.hero');
  if (!header || !hero) return;

  const syncHeader = () => {
    const start = hero.offsetHeight - header.offsetHeight;
    header.classList.toggle('is-sticky', window.scrollY > start);
  };

  window.addEventListener('scroll', syncHeader, { passive: true });
  window.addEventListener('resize', syncHeader);
  window.addEventListener('load', syncHeader);
  window.addEventListener('hashchange', syncHeader);
  syncHeader();
  requestAnimationFrame(syncHeader);
})();
