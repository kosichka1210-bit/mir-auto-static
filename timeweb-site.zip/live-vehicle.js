(() => {
  'use strict';
  const API = 'https://bot.mir-auto-china.ru/api/cars.php';
  const API_ORIGIN = new URL(API).origin;
  const siteRoot = new URL(location.pathname.includes('/mir-auto-static/') ? '/mir-auto-static/' : '/', location.origin);
  const grid = document.querySelector('.vehicle-grid');
  const slug = new URLSearchParams(location.search).get('slug') || '';
  const esc = (value) => String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  const formatNumber = (value) => new Intl.NumberFormat('ru-RU').format(Number(value));
  const imageUrl = (value) => {
    const source = String(value || '').trim();
    if (!source) return '';
    try { return new URL(source, `${API_ORIGIN}/`).href; } catch (_) { return ''; }
  };
  const markUnavailable = (title) => {
    document.title = `${title} — MIR AUTO`;
    let robots = document.head.querySelector('meta[name="robots"]');
    if (!robots) { robots = document.createElement('meta'); robots.name = 'robots'; document.head.append(robots); }
    robots.content = 'noindex,follow';
    if (grid) grid.innerHTML = '<section class="vehicle-not-found"><h1>Автомобиль не найден</h1><p>Возможно, предложение уже снято с публикации.</p><a class="button" href="/avtomobili/">Вернуться в каталог</a></section>';
  };
  if (!grid || !/^[a-z0-9-]{1,150}$/.test(slug)) { markUnavailable('Автомобиль не найден'); return; }

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 8000);
  fetch(`${API}?slug=${encodeURIComponent(slug)}`, { headers: { Accept: 'application/json' }, signal: controller.signal })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('api')))
    .then((payload) => {
      const car = payload && Array.isArray(payload.cars) ? payload.cars[0] : null;
      if (!car) throw new Error('not-found');
      const title = car.title || [car.brand, car.model].filter(Boolean).join(' ');
      const descriptionLead = 'Автомобиль из опубликованного предложения MIR AUTO.';
      const rawDescription = String(car.description || '').trim();
      const description = rawDescription
        ? (/^Автомобиль из опубликованного предложения MIR AUTO\./i.test(rawDescription)
          ? rawDescription
          : `${descriptionLead} ${rawDescription}`)
        : `${descriptionLead} Представители MIR AUTO проконсультируют по автомобилю и дальнейшему процессу.`;
      const images = Array.isArray(car.images) ? car.images.map(imageUrl).filter(Boolean) : [];
      const specs = [
        ['Год', car.year], ['Пробег', car.mileage_km ? `${formatNumber(car.mileage_km)} км` : ''],
        ['Двигатель', [car.engine, car.power].filter(Boolean).join(' · ')], ['Привод', car.drive],
        ['Коробка передач', car.transmission], ['Комплектация', car.equipment]
      ].filter(([, value]) => value);
      const gallery = images.length ? `<section class="vehicle-gallery"><div class="vehicle-gallery-stage"><img class="vehicle-gallery-main" src="${esc(images[0])}" alt="${esc(title)} из Китая — MIR AUTO">${images.length > 1 ? '<button class="gallery-arrow gallery-prev" type="button" aria-label="Предыдущее фото">←</button><button class="gallery-arrow gallery-next" type="button" aria-label="Следующее фото">→</button>' : ''}</div>${images.length > 1 ? `<div class="gallery-thumbs">${images.map((image,index)=>`<button class="gallery-thumb${index===0?' is-active':''}" type="button" data-index="${index}"><img src="${esc(image)}" alt="${esc(title)} — фото ${index+1}"></button>`).join('')}</div>` : ''}</section>` : '<section class="vehicle-gallery"><div class="vehicle-gallery-stage is-missing"><span>Фото скоро</span></div></section>';
      const price = car.price_rub ? `${formatNumber(car.price_rub)} ₽` : 'Цена по запросу';
      const canonicalUrl = new URL(`avtomobili/${encodeURIComponent(slug)}/`, siteRoot).href;
      const setMeta = (selector, value) => {
        let element = document.head.querySelector(selector);
        if (!element) {
          const identity = selector.match(/^meta\[(name|property)="([^"]+)"\]$/);
          if (!identity) return;
          element = document.createElement('meta');
          element.setAttribute(identity[1], identity[2]);
          document.head.append(element);
        }
        element.setAttribute('content', value);
      };
      const canonical = document.head.querySelector('link[rel="canonical"]') || document.head.appendChild(document.createElement('link'));
      canonical.rel = 'canonical';
      canonical.href = canonicalUrl;
      document.title = `${title} — MIR AUTO`;
      setMeta('meta[name="description"]', description);
      setMeta('meta[property="og:title"]', `${title} — MIR AUTO`);
      setMeta('meta[property="og:description"]', description);
      setMeta('meta[property="og:url"]', canonicalUrl);
      if (images[0]) setMeta('meta[property="og:image"]', images[0]);
      setMeta('meta[name="twitter:card"]', 'summary_large_image');
      setMeta('meta[name="twitter:title"]', `${title} — MIR AUTO`);
      setMeta('meta[name="twitter:description"]', description);
      const contactUrl = new URL('#form', siteRoot).href;
      grid.innerHTML = `${gallery}<section class="vehicle-details"><p class="status">${esc(car.status || 'В наличии')}</p><h1>${esc(title)}</h1><p class="vehicle-price">${price}</p>${car.price_location ? `<p class="vehicle-note">Стоимость для ${esc(car.price_location)}. Уточняйте актуальность.</p>` : ''}${specs.length ? `<dl class="spec-list">${specs.map(([label,value])=>`<div><dt>${label}</dt><dd>${esc(value)}</dd></div>`).join('')}</dl>` : ''}<p class="vehicle-text">${esc(description)}</p><div class="vehicle-actions"><a class="button" href="${contactUrl}">Обсудить автомобиль</a><a class="button button-outline" href="https://t.me/mirautochina125" target="_blank" rel="noopener">Написать в Telegram</a></div></section>`;
      const main = grid.querySelector('.vehicle-gallery-main');
      const stage = grid.querySelector('.vehicle-gallery-stage');
      if (main) main.addEventListener('error', () => {
        main.hidden = true;
        stage.classList.add('is-missing');
      });
      grid.querySelectorAll('.gallery-thumb img').forEach((thumb) => thumb.addEventListener('error', () => {
        thumb.closest('.gallery-thumb').hidden = true;
      }));
      if (images.length < 2) return;
      let current = 0; const thumbs = [...grid.querySelectorAll('.gallery-thumb')];
      const show = (index) => { current = (index + images.length) % images.length; main.src = images[current]; thumbs.forEach((thumb,i)=>thumb.classList.toggle('is-active',i===current)); };
      grid.querySelector('.gallery-prev').addEventListener('click',()=>show(current-1)); grid.querySelector('.gallery-next').addEventListener('click',()=>show(current+1)); thumbs.forEach((thumb)=>thumb.addEventListener('click',()=>show(Number(thumb.dataset.index))));
      let startX=0; main.addEventListener('touchstart',(event)=>{startX=event.changedTouches[0].screenX;},{passive:true}); main.addEventListener('touchend',(event)=>{const delta=event.changedTouches[0].screenX-startX;if(Math.abs(delta)>40)show(current+(delta<0?1:-1));},{passive:true});
    })
    .catch(() => { markUnavailable('Автомобиль не найден или временно недоступен'); })
    .finally(() => window.clearTimeout(timeout));
})();
