(() => {
  'use strict';
  const API = 'https://bot.mir-auto-china.ru/api/cars.php';
  const grid = document.querySelector('.vehicle-grid');
  const slug = new URLSearchParams(location.search).get('slug') || '';
  const esc = (value) => String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  const formatNumber = (value) => new Intl.NumberFormat('ru-RU').format(Number(value));
  if (!grid || !/^[a-z0-9-]+$/.test(slug)) { if (grid) grid.innerHTML = '<p>Автомобиль не найден.</p>'; return; }

  fetch(`${API}?slug=${encodeURIComponent(slug)}`, { headers: { Accept: 'application/json' } })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('api')))
    .then((payload) => {
      const car = payload && Array.isArray(payload.cars) ? payload.cars[0] : null;
      if (!car) throw new Error('not-found');
      const title = car.title || [car.brand, car.model].filter(Boolean).join(' ');
      const images = Array.isArray(car.images) ? car.images.filter(Boolean) : [];
      const specs = [
        ['Год', car.year], ['Пробег', car.mileage_km ? `${formatNumber(car.mileage_km)} км` : ''],
        ['Двигатель', [car.engine, car.power].filter(Boolean).join(' · ')], ['Привод', car.drive],
        ['Коробка передач', car.transmission], ['Комплектация', car.equipment]
      ].filter(([, value]) => value);
      const gallery = images.length ? `<section class="vehicle-gallery"><div class="vehicle-gallery-stage"><img class="vehicle-gallery-main" src="${esc(images[0])}" alt="${esc(title)}">${images.length > 1 ? '<button class="gallery-arrow gallery-prev" type="button" aria-label="Предыдущее фото">←</button><button class="gallery-arrow gallery-next" type="button" aria-label="Следующее фото">→</button>' : ''}</div>${images.length > 1 ? `<div class="gallery-thumbs">${images.map((image,index)=>`<button class="gallery-thumb${index===0?' is-active':''}" type="button" data-index="${index}"><img src="${esc(image)}" alt="${esc(title)} — фото ${index+1}"></button>`).join('')}</div>` : ''}</section>` : '';
      const price = car.price_rub ? `${formatNumber(car.price_rub)} ₽` : 'Цена по запросу';
      grid.innerHTML = `${gallery}<section class="vehicle-details"><p class="status">${esc(car.status || 'В наличии')}</p><h1>${esc(title)}</h1><p class="vehicle-price">${price}</p>${car.price_location ? `<p class="vehicle-note">Стоимость для ${esc(car.price_location)}. Уточняйте актуальность.</p>` : ''}${specs.length ? `<dl class="spec-list">${specs.map(([label,value])=>`<div><dt>${label}</dt><dd>${esc(value)}</dd></div>`).join('')}</dl>` : ''}${car.description ? `<p class="vehicle-text">${esc(car.description)}</p>` : ''}<div class="vehicle-actions"><a class="button" href="../../#form">Обсудить автомобиль</a><a class="button button-outline" href="https://t.me/mirautochina125" target="_blank" rel="noopener">Написать в Telegram</a></div></section>`;
      document.title = `${title} — MIR AUTO`;
      if (images.length < 2) return;
      let current = 0; const main = grid.querySelector('.vehicle-gallery-main'); const thumbs = [...grid.querySelectorAll('.gallery-thumb')];
      const show = (index) => { current = (index + images.length) % images.length; main.src = images[current]; thumbs.forEach((thumb,i)=>thumb.classList.toggle('is-active',i===current)); };
      grid.querySelector('.gallery-prev').addEventListener('click',()=>show(current-1)); grid.querySelector('.gallery-next').addEventListener('click',()=>show(current+1)); thumbs.forEach((thumb)=>thumb.addEventListener('click',()=>show(Number(thumb.dataset.index))));
      let startX=0; main.addEventListener('touchstart',(event)=>{startX=event.changedTouches[0].screenX;},{passive:true}); main.addEventListener('touchend',(event)=>{const delta=event.changedTouches[0].screenX-startX;if(Math.abs(delta)>40)show(current+(delta<0?1:-1));},{passive:true});
    })
    .catch(() => { grid.innerHTML = '<p>Автомобиль не найден или каталог временно недоступен.</p>'; });
})();
